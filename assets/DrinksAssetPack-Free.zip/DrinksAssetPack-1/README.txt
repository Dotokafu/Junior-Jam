==================================================
          COFFEE ASSET PACK by mimi
==================================================

Thank you so much for downloading this asset pack! 
Whether you're building a cozy prototype, a game jam entry, or a full project, 
I hope these graphics help bring your world to life.

--------------------------------------------------
ABOUT THIS PACK + WHATS INSIDE
--------------------------------------------------
- Pixel-style Coffee Sprites!
- Canvas Size: 96x96px PNGs
- Full Sprite Sheet with all the coffees
- Bonus empty sprites of a teacup and coffee cup
  so you can also make your own!

--------------------------------------------------
SUPPORT & CONNECT
--------------------------------------------------
Created by: Mimi
Itch.io Page: https://akiesque.itch.io
Instagram: @mochimisu

If you use these in a game, I'd LOVE to see it! 
Feel free to leave a link on the itch.io store page or drop a comment.

For license terms, please see the included LICENSE.txt file.